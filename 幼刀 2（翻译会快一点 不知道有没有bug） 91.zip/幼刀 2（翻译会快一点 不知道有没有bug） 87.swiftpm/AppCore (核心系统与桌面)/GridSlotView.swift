// 📄 替换文件：AppCore (核心系统与桌面)/GridSlotView.swift
import SwiftUI

// 📄 原生图片渲染组件
struct NativeImage: View {
    var data: Data?
    var body: some View {
        if let uiImage = ImageBitmapCache.shared.image(from: data) {
            Image(uiImage: uiImage).resizable().scaledToFill()
        } else {
            Color.white
        }
    }
}

// 📄 桌面 App 单个图标 UI
struct AppIcon: View {
    var icon: String
    var color: Color
    var title: String? = nil
    var textColor: Color = .white
    var customImageData: Data? = nil
    var action: () -> Void
    
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    @ObservedObject var borderManager = IconBorderManager.shared
    
    var body: some View {
        let s = uiScale
        VStack(spacing: 3.5 * s) {
            Button(action: action) {
                Group {
                    if let uiImage = ImageBitmapCache.shared.image(from: customImageData) {
                        Image(uiImage: uiImage)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 58.0 * s, height: 58.0 * s)
                            .clipShape(RoundedRectangle(cornerRadius: 15.5 * s, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 15.5 * s, style: .continuous)
                                    .stroke(Color.white.opacity(0.18), lineWidth: 0.8 * s)
                            )
                    } else {
                        Image(systemName: icon)
                            .font(.system(size: 33.0 * s))
                            .foregroundColor(.white)
                            .frame(width: 58.0 * s, height: 58.0 * s)
                            .background(color)
                            .clipShape(RoundedRectangle(cornerRadius: 15.5 * s, style: .continuous))
                    }
                }
                .applyIconBorder(cornerRadius: 15.5)
            }
            if let title = title {
                Text(translator.translate(title))
                    .font(.system(size: 11 * s))
                    .fontWeight(appearance.systemFontWeight)
                    .foregroundColor(textColor)
                    .lineLimit(1)
            }
        }
    }
}

// 📄 桌面网格单个槽位视图
struct GridSlotView: View {
    let slotIndex: Int
    let item: AppItem?
    let isEditing: Bool
    let isBeingDragged: Bool
    let textColor: Color
    let customTitle: String?
    let customImageData: Data?
    let onLaunch: () -> Void
    let onEnterEdit: () -> Void
    let onDragStart: (AppItem, CGPoint) -> Void
    let onDragChange: (CGPoint) -> Void
    let onDragEnd: (CGPoint) -> Void
    
    @ObservedObject var lang = LanguageManager.shared
    @ObservedObject var iconManager = CustomIconManager.shared
    
    @GestureState private var dragActive: Bool = false
    @State private var lastDragLocation: CGPoint = .zero
    
    var body: some View {
        ZStack(alignment: .top) {
            if let item = item {
                let displayTitle = item.localizedTitle(customManager: iconManager, lang: lang)
                let itemColor = item.displayColor(customManager: iconManager)
                if isEditing {
                    AppIcon(icon: item.icon, color: itemColor, title: displayTitle, textColor: textColor, customImageData: customImageData) {}
                        .id("app_\(item.id)")
                        .opacity(isBeingDragged ? 0.0 : 1.0)
                        .transition(.identity)
                        .highPriorityGesture(
                            DragGesture(minimumDistance: 0, coordinateSpace: .global)
                                .updating($dragActive) { _, state, _ in state = true }
                                .onChanged { val in
                                    lastDragLocation = val.location
                                    if !isBeingDragged { onDragStart(item, val.location) }
                                    else { onDragChange(val.location) }
                                }
                                .onEnded { val in onDragEnd(val.location) }
                        )
                        .onChange(of: dragActive) { _, isActive in
                            if !isActive && isBeingDragged { onDragEnd(lastDragLocation) }
                        }
                } else {
                    AppIcon(icon: item.icon, color: itemColor, title: displayTitle, textColor: textColor, customImageData: customImageData) { onLaunch() }
                        .id("app_\(item.id)")
                        .transition(.identity)
                        .simultaneousGesture(
                            LongPressGesture(minimumDuration: 0.45).onEnded { _ in
                                if !isEditing {
                                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                                    onEnterEdit()
                                }
                            }
                        )
                }
            } else {
                Color.clear
                    .contentShape(Rectangle())
                    .simultaneousGesture(
                        LongPressGesture(minimumDuration: 0.45).onEnded { _ in
                            if !isEditing {
                                UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                                onEnterEdit()
                            }
                        }
                    )
                    .transition(.identity)
            }
        }
        .modifier(JiggleModifier(isEditing: isEditing, isWidget: false, customDelayIndex: slotIndex))
        .frame(maxWidth: .infinity)
        .frame(height: 78.0 * uiScale, alignment: .top)
        .contentShape(Rectangle())
        .transition(.identity)
    }
}

// 📄 Dock 栏单个图标槽位
struct DockItemView: View {
    let dockIndex: Int
    let item: AppItem
    let isEditing: Bool
    let isBeingDragged: Bool
    let customImageData: Data?
    let onLaunch: () -> Void
    let onEnterEdit: () -> Void
    let onDragStart: (AppItem, CGPoint) -> Void
    let onDragChange: (CGPoint) -> Void
    let onDragEnd: (CGPoint) -> Void
    
    @ObservedObject var iconManager = CustomIconManager.shared
    
    @GestureState private var dragActive: Bool = false
    @State private var lastDragLocation: CGPoint = .zero
    
    var body: some View {
        let itemColor = item.displayColor(customManager: iconManager)
        return ZStack {
            if isEditing {
                AppIcon(icon: item.icon, color: itemColor, customImageData: customImageData) {}
                    .id("dock_\(item.id)")
                    .opacity(isBeingDragged ? 0.0 : 1.0)
                    .transition(.identity)
                    .highPriorityGesture(
                        DragGesture(minimumDistance: 0, coordinateSpace: .global)
                            .updating($dragActive) { _, state, _ in state = true }
                            .onChanged { val in
                                lastDragLocation = val.location
                                if !isBeingDragged { onDragStart(item, val.location) }
                                else { onDragChange(val.location) }
                            }
                            .onEnded { val in onDragEnd(val.location) }
                    )
                    .onChange(of: dragActive) { _, isActive in
                        if !isActive && isBeingDragged { onDragEnd(lastDragLocation) }
                    }
            } else {
                AppIcon(icon: item.icon, color: itemColor, customImageData: customImageData) { onLaunch() }
                    .id("dock_\(item.id)")
                    .transition(.identity)
                    .simultaneousGesture(
                        LongPressGesture(minimumDuration: 0.45).onEnded { _ in
                            if !isEditing {
                                UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                                onEnterEdit()
                            }
                        }
                    )
            }
        }
        .modifier(JiggleModifier(isEditing: isEditing, isWidget: false, customDelayIndex: abs(item.id.hashValue) % 10))
        .transition(.identity)
    }
}

// 📄 拖拽跟手浮动层 (图标)
struct ActiveDragOverlay: View {
    @ObservedObject var coordinator: DragCoordinator
    @ObservedObject var tracker: DragPositionTracker
    @ObservedObject var iconManager = CustomIconManager.shared
    @ObservedObject var lang = LanguageManager.shared
    let rootOrigin: CGPoint
    let screenH: CGFloat
    let contentColor: Color
    
    var body: some View {
        Group {
            if let dragged = coordinator.activeDraggingItem {
                let localPoint = CGPoint(
                    x: tracker.location.x - rootOrigin.x,
                    y: tracker.location.y - rootOrigin.y
                )
                let isNearDock = localPoint.y >= (screenH - (171.0 * uiScale))
                let shouldHideTitle = isNearDock || (coordinator.activeDragSource?.isDock == true && localPoint.y >= (screenH - (171.0 * uiScale)))
                let displayTitle = dragged.localizedTitle(customManager: iconManager, lang: lang)
                let itemColor = dragged.displayColor(customManager: iconManager)
                
                AppIcon(
                    icon: dragged.icon,
                    color: itemColor,
                    title: displayTitle,
                    textColor: contentColor.opacity(shouldHideTitle ? 0.0 : 1.0),
                    customImageData: iconManager.getIcon(for: dragged.id)
                ) {}
                    .frame(width: 58.0 * uiScale, height: 58.0 * uiScale)
                    .position(localPoint)
                    .allowsHitTesting(false)
                    .zIndex(99999)
            }
        }
    }
}

// 📄 拖拽跟手浮动层 (小组件)
struct GlobalWidgetDragOverlay: View {
    @ObservedObject var widgetCoordinator: WidgetDragCoordinator
    @ObservedObject var tracker: DragPositionTracker
    @ObservedObject var registry = WidgetRegistry.shared
    let screenW: CGFloat
    let gridTopOffsetY: CGFloat
    let widget4xHeight: CGFloat
    let widget2xHeight: CGFloat
    
    var body: some View {
        Group {
            if let activeId = widgetCoordinator.activeWidgetId,
               let def = registry.widget(for: activeId) {
                let fullWidth = max(0, screenW - (48.0 * uiScale))
                let halfWidth = max(0, (fullWidth - (18.0 * uiScale)) / 2.0)
                let targetWidth = def.sizeCols >= 4 ? fullWidth : halfWidth
                let targetHeight = def.sizeRows >= 4 ? widget4xHeight : widget2xHeight
                
                def.desktopView()
                    .frame(width: targetWidth, height: targetHeight)
                    .scaleEffect(1.02)
                    .shadow(color: Color.black.opacity(0.18), radius: 14.0 * uiScale, y: 7.0 * uiScale)
                    .offset(
                        x: (24.0 * uiScale) + widgetCoordinator.initialOriginX + tracker.offset.width,
                        y: gridTopOffsetY + widgetCoordinator.initialOriginY + tracker.offset.height
                    )
                    .allowsHitTesting(false)
                    .zIndex(99999)
                    .transition(.identity)
            }
        }
        .transaction { transaction in transaction.animation = nil }
    }
}
