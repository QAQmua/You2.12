import SwiftUI

// 📄 App 实体模型
struct AppItem: Identifiable, Codable, Equatable {
    let id: String
    var title: String
    var icon: String
    var colorName: String
    
    // 默认莫兰迪低饱和色系映射（彻底干掉高饱和鲜艳大红大绿）
    var defaultMorandiHex: String {
        switch id {
        case "wechat": return "#8FA4B5"     // 微信：莫兰迪雾蓝
        case "messages": return "#9DB3C4"   // 信息：莫兰迪清爽蓝
        case "phone": return "#9EA3A8"      // 电话：莫兰迪雅灰
        case "weather": return "#A3B8C8"    // 天气：莫兰迪淡蓝
        case "iscreen": return "#A39BAE"    // iScreen：莫兰迪灰紫
        case "notes": return "#C8A8A8"      // 手记：莫兰迪柔粉
        case "qimao": return "#D6BDBD"      // 七猫小说：莫兰迪豆沙粉
        case "anonymous": return "#B5ADC0"  // 匿名：莫兰迪丁香灰紫
        case "icity": return "#8FA4B5"      // iCity：莫兰迪雾蓝
        case "music_app": return "#C49A9A"  // 网易云：莫兰迪冷粉
        case "settings": return "#B4B8BC"   // 设置：莫兰迪素灰
        default: return "#9EA3A8"
        }
    }
    
    func displayColor(customManager: CustomIconManager) -> Color {
        if let hex = customManager.getColor(for: self.id), !hex.isEmpty {
            return Color(hex: hex)
        }
        return Color(hex: defaultMorandiHex)
    }
    
    var color: Color {
        displayColor(customManager: CustomIconManager.shared)
    }
    
    func localizedTitle(customManager: CustomIconManager, lang: LanguageManager) -> String {
        if let custom = customManager.getTitle(for: self.id), !custom.isEmpty {
            return AutoTranslationManager.shared.translate(custom, to: lang.currentLanguage)
        }
        let directKeyMatch = lang.tr(self.title)
        if directKeyMatch != self.title { return directKeyMatch }
        let appKeyMatch = lang.tr("app_\(self.id)")
        if appKeyMatch != "app_\(self.id)" { return appKeyMatch }
        return AutoTranslationManager.shared.translate(self.title, to: lang.currentLanguage)
    }
}

// 📄 拖拽位置枚举
enum AppLocation: Equatable {
    case grid(Int)
    case dock(Int)
    
    var isDock: Bool {
        if case .dock = self { return true }
        return false
    }
}

// 📄 设置应用路由
enum SettingsRoute: Hashable {
    case language
    case appearance
    case wallpaper
    case apiConfig
}

class SettingsNavManager: ObservableObject {
    static let shared = SettingsNavManager()
    @Published var path: [SettingsRoute] = []
    @Published var isInteractingWithSlider: Bool = false
}

// 📄 自定义 App 图标、色彩与名称管理器
class CustomIconManager: ObservableObject {
    static let shared = CustomIconManager()
    
    private let titleStorageKey = "App_Custom_App_Titles_Map"
    private let iconIdStorageKey = "App_Custom_App_IconIDs_Map"
    private let colorStorageKey = "App_Custom_App_Colors_Map"
    
    @Published var customIcons: [String: Data] = [:]
    
    @Published var customIconIDs: [String: String] = [:] {
        didSet {
            Task.detached(priority: .utility) {
                if let data = try? JSONEncoder().encode(self.customIconIDs) {
                    UserDefaults.standard.set(data, forKey: self.iconIdStorageKey)
                }
            }
        }
    }
    
    @Published var customTitles: [String: String] = [:] {
        didSet {
            Task.detached(priority: .utility) {
                if let data = try? JSONEncoder().encode(self.customTitles) {
                    UserDefaults.standard.set(data, forKey: self.titleStorageKey)
                }
            }
        }
    }
    
    // 🌟 主桌面各应用图标背景色字典 [AppId: HexColor]
    @Published var customColors: [String: String] = [:] {
        didSet {
            Task.detached(priority: .utility) {
                if let data = try? JSONEncoder().encode(self.customColors) {
                    UserDefaults.standard.set(data, forKey: self.colorStorageKey)
                }
            }
        }
    }
    
    init() {
        if let data = UserDefaults.standard.data(forKey: titleStorageKey),
           let decoded = try? JSONDecoder().decode([String: String].self, from: data) {
            self.customTitles = decoded
            for title in self.customTitles.values {
                AutoTranslationManager.shared.prewarm(text: title)
            }
        }
        
        if let data = UserDefaults.standard.data(forKey: iconIdStorageKey),
           let decoded = try? JSONDecoder().decode([String: String].self, from: data) {
            self.customIconIDs = decoded
            for (appId, imageId) in decoded {
                if let imageData = LocalImageStore.shared.load(id: imageId) {
                    self.customIcons[appId] = imageData
                    _ = ImageBitmapCache.shared.image(from: imageData)
                }
            }
        }
        
        if let data = UserDefaults.standard.data(forKey: colorStorageKey),
           let decoded = try? JSONDecoder().decode([String: String].self, from: data) {
            self.customColors = decoded
        }
    }
    
    func setIcon(for appId: String, imageData: Data) {
        customIcons[appId] = imageData
        _ = ImageBitmapCache.shared.image(from: imageData)
        
        let oldId = customIconIDs[appId]
        LocalImageStore.shared.replace(oldId: oldId, with: imageData) { newId in
            if let newId = newId {
                self.customIconIDs[appId] = newId
            }
        }
    }
    
    func removeIcon(for appId: String) {
        if let oldData = customIcons[appId] {
            ImageBitmapCache.shared.remove(for: oldData)
        }
        customIcons.removeValue(forKey: appId)
        if let oldId = customIconIDs[appId] {
            LocalImageStore.shared.delete(id: oldId)
            customIconIDs.removeValue(forKey: appId)
        }
    }
    
    func getIcon(for appId: String) -> Data? {
        return customIcons[appId]
    }
    
    func setTitle(for appId: String, title: String) {
        let trimmed = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            customTitles.removeValue(forKey: appId)
        } else {
            customTitles[appId] = trimmed
            Task {
                for lang in AppLanguage.allCases where lang != .simplifiedChinese {
                    _ = await AutoTranslationManager.shared.translateAsync(trimmed, to: lang)
                }
            }
        }
    }
    
    func removeTitle(for appId: String) {
        customTitles.removeValue(forKey: appId)
    }
    
    func getTitle(for appId: String) -> String? {
        return customTitles[appId]
    }
    
    // 🌟 图标色彩存取接口
    func setColor(for appId: String, hex: String) {
        customColors[appId] = hex
        objectWillChange.send()
    }
    
    func getColor(for appId: String) -> String? {
        return customColors[appId]
    }
}
