// MARK: - 10. SettingsView (设置应用中心)
import SwiftUI
import PhotosUI
import UIKit

// 🌟 挂载独立自注册身份证
final class SettingsAppPlugin: BaseAppPlugin {
    override class var id: String { "settings" }
    override class var name: String { "设置" }
    override class var icon: String { "gearshape.fill" }
    override class var colorName: String { "gray" }
    override class func buildView(show: Binding<Bool>) -> AnyView {
        AnyView(SettingsView(show: show))
    }
}

struct SettingsView: View {
    @Binding var show: Bool
    @ObservedObject var appearance = SystemAppearance.shared 
    @ObservedObject var lang = LanguageManager.shared
    @ObservedObject var navManager = SettingsNavManager.shared
    
    var body: some View {
        NavigationStack(path: $navManager.path) {
            List {
                Section {
                    HStack(spacing: 15) {
                        Image(systemName: "person.crop.circle.fill")
                            .font(.system(size: 45))
                            .foregroundColor(.gray)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(lang.tr("device_name"))
                                .font(.system(size: 19, weight: appearance.systemFontWeight))
                            Text(lang.tr("apple_id_sub"))
                                .font(.system(size: 12, weight: appearance.systemFontWeight))
                                .foregroundColor(.gray)
                        }
                    }
                    .padding(.vertical, 4)
                }
                
                Section {
                    NavigationLink(value: SettingsRoute.language) {
                        HStack {
                            Image(systemName: "globe")
                                .font(.system(size: 14))
                                .foregroundColor(.white)
                                .frame(width: 28, height: 28)
                                .background(appearance.settingsLanguageIconColor)
                                .cornerRadius(6)
                            Text(lang.tr("language_title"))
                                .font(.system(size: 16, weight: appearance.systemFontWeight))
                            Spacer()
                            Text(lang.currentLanguage.displayName)
                                .font(.system(size: 14, weight: appearance.systemFontWeight))
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    NavigationLink(value: SettingsRoute.appearance) {
                        HStack {
                            Image(systemName: "textformat.size")
                                .font(.system(size: 14))
                                .foregroundColor(.white)
                                .frame(width: 28, height: 28)
                                .background(appearance.settingsAppearanceIconColor)
                                .cornerRadius(6)
                            Text(lang.tr("display_and_brightness"))
                                .font(.system(size: 16, weight: appearance.systemFontWeight))
                        }
                    }
                    
                    NavigationLink(value: SettingsRoute.wallpaper) {
                        HStack {
                            Image(systemName: "photo.on.rectangle")
                                .font(.system(size: 14))
                                .foregroundColor(.white)
                                .frame(width: 28, height: 28)
                                .background(appearance.settingsWallpaperIconColor)
                                .cornerRadius(6)
                            Text(lang.tr("wallpaper"))
                                .font(.system(size: 16, weight: appearance.systemFontWeight))
                        }
                    }
                }
                
                Section {
                    NavigationLink(value: SettingsRoute.apiConfig) {
                        HStack {
                            Image(systemName: "network")
                                .font(.system(size: 14))
                                .foregroundColor(.white)
                                .frame(width: 28, height: 28)
                                .background(appearance.settingsApiIconColor)
                                .cornerRadius(6)
                            Text(lang.tr("api_config"))
                                .font(.system(size: 16, weight: appearance.systemFontWeight))
                        }
                    }
                }
            }
            .navigationDestination(for: SettingsRoute.self) { route in
                switch route {
                case .language:
                    LanguageSettingsView()
                case .appearance:
                    AppearanceSettingsView()
                case .wallpaper:
                    WallpaperSettingsView()
                case .apiConfig:
                    APIConfigSettingsView()
                }
            }
            .navigationTitle(lang.tr("settings_title"))
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(lang.tr("done")) {
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) {
                            show = false
                            navManager.path = []
                        }
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                    .foregroundColor(appearance.accentTextColor)
                }
            }
            .background(Color(UIColor.systemBackground))
        }
        .preferredColorScheme(appearance.colorScheme)
        .tint(appearance.accentTextColor)
        .simultaneousGesture(
            DragGesture(minimumDistance: 15)
                .onEnded { value in
                    guard !navManager.isInteractingWithSlider else { return }
                    if value.translation.width > 50 && abs(value.translation.width) > abs(value.translation.height) {
                        let generator = UIImpactFeedbackGenerator(style: .light)
                        generator.impactOccurred()
                        
                        if !navManager.path.isEmpty {
                            withAnimation(.easeInOut(duration: 0.22)) {
                                _ = navManager.path.popLast()
                            }
                        } else {
                            withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) {
                                show = false
                            }
                        }
                    }
                }
        )
    }
}

// MARK: - 语言设置子页面
struct LanguageSettingsView: View {
    @ObservedObject var lang = LanguageManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    
    var body: some View {
        List {
            Section {
                ForEach(AppLanguage.allCases) { item in
                    HStack {
                        Text(item.displayName)
                            .font(.system(size: 16, weight: appearance.systemFontWeight))
                            .foregroundColor(.primary)
                        Spacer()
                        Image(systemName: "checkmark")
                            .foregroundColor(appearance.accentTextColor)
                            .font(.system(size: 14, weight: .bold))
                            .opacity(lang.currentLanguage == item ? 1.0 : 0.0)
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        let generator = UIImpactFeedbackGenerator(style: .light)
                        generator.impactOccurred()
                        lang.currentLanguage = item
                    }
                }
            }
        }
        .navigationTitle(lang.tr("language_title"))
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - 外观与亮度设置
enum AppearanceColorItem: Identifiable {
    case sliderTrack
    case toggleTint
    case categoryTag
    case accentText
    case tabBarSelected
    
    case setLangIcon
    case setAppIcon
    case setWallIcon
    case setApiIcon
    
    case desktopApp(id: String, name: String)
    
    var id: String {
        switch self {
        case .sliderTrack: return "sliderTrack"
        case .toggleTint: return "toggleTint"
        case .categoryTag: return "categoryTag"
        case .accentText: return "accentText"
        case .tabBarSelected: return "tabBarSelected"
        case .setLangIcon: return "setLangIcon"
        case .setAppIcon: return "setAppIcon"
        case .setWallIcon: return "setWallIcon"
        case .setApiIcon: return "setApiIcon"
        case .desktopApp(let appId, _): return "desktopApp_\(appId)"
        }
    }
    
    var title: String {
        switch self {
        case .sliderTrack: return "系统滑块条轨道颜色".tr
        case .toggleTint: return "开关/开启按钮背景颜色".tr
        case .categoryTag: return "各种分类标签颜色".tr
        case .accentText: return "系统自带交互文字颜色".tr
        case .tabBarSelected: return "底部标签栏图标与选中颜色".tr
        case .setLangIcon: return "设置「语言」图标背景颜色".tr
        case .setAppIcon: return "设置「显示与亮度」图标背景颜色".tr
        case .setWallIcon: return "设置「壁纸」图标背景颜色".tr
        case .setApiIcon: return "设置「API配置」图标背景颜色".tr
        case .desktopApp(_, let name): return "桌面「\(name)」图标背景颜色".tr
        }
    }
    
    var storageKey: String {
        switch self {
        case .sliderTrack: return "slider_track_color"
        case .toggleTint: return "toggle_tint_color"
        case .categoryTag: return "category_tag_color"
        case .accentText: return "accent_text_color"
        case .tabBarSelected: return "tabbar_selected_color"
        case .setLangIcon: return "set_lang_icon_color"
        case .setAppIcon: return "set_app_icon_color"
        case .setWallIcon: return "set_wall_icon_color"
        case .setApiIcon: return "set_api_icon_color"
        case .desktopApp(let appId, _): return "desktop_app_\(appId)"
        }
    }
}

struct AppearanceSettingsView: View {
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var lang = LanguageManager.shared
    @ObservedObject var iconManager = CustomIconManager.shared
    
    @State private var activeSheetItem: AppearanceColorItem? = nil
    
    // 主桌面应用清单（精细拆分）
    private let desktopAppList: [(id: String, name: String)] = [
        ("wechat", "微信"),
        ("messages", "信息"),
        ("phone", "电话"),
        ("weather", "天气"),
        ("iscreen", "iScreen"),
        ("notes", "手记"),
        ("qimao", "七猫小说"),
        ("anonymous", "匿名"),
        ("icity", "iCity"),
        ("music_app", "网易云音乐"),
        ("settings", "设置")
    ]
    
    private let fontWeights: [(key: String, title: String)] = [
        ("light", "细体"),
        ("regular", "标准"),
        ("medium", "中等"),
        ("semibold", "半粗"),
        ("bold", "粗体")
    ]
    
    var body: some View {
        Form {
            Section(
                header: Text(lang.tr("appearance")).font(.system(size: 13, weight: appearance.systemFontWeight)),
                footer: Text(lang.tr("appearance_auto_footer")).font(.system(size: 12, weight: appearance.systemFontWeight))
            ) {
                Toggle(lang.tr("auto"), isOn: $appearance.isAuto)
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                    .tint(appearance.toggleTintColor)
                
                if !appearance.isAuto {
                    Picker(lang.tr("appearance_selection"), selection: $appearance.isDark) {
                        Text(lang.tr("light")).tag(false)
                        Text(lang.tr("dark")).tag(true)
                    }
                    .pickerStyle(.segmented)
                    .padding(.vertical, 4)
                }
            }
            
            // MARK: - 系统基础交互色彩
            Section(
                header: Text("系统全局色彩与交互".tr).font(.system(size: 13, weight: appearance.systemFontWeight))
            ) {
                colorRowButton(item: .sliderTrack, hex: appearance.sliderTrackColorHex)
                colorRowButton(item: .toggleTint, hex: appearance.toggleTintColorHex)
                colorRowButton(item: .categoryTag, hex: appearance.categoryTagColorHex)
                colorRowButton(item: .accentText, hex: appearance.accentTextColorHex)
                colorRowButton(item: .tabBarSelected, hex: appearance.tabBarSelectedColorHex)
            }
            
            // MARK: - 🌟 主桌面各应用图标色彩（每个独立精细配置，无组合式）
            Section(
                header: Text("主桌面各应用图标色彩（精细单项）".tr).font(.system(size: 13, weight: appearance.systemFontWeight)),
                footer: Text("桌面与 Dock 栏对应 App 图标背景色将实时同步生效。".tr).font(.system(size: 12, weight: appearance.systemFontWeight))
            ) {
                ForEach(desktopAppList, id: \.id) { app in
                    let currentHex = iconManager.getColor(for: app.id) ?? defaultHexFor(app.id)
                    Button(action: {
                        activeSheetItem = .desktopApp(id: app.id, name: app.name)
                    }) {
                        HStack {
                            Text("桌面「\(app.name.tr)」图标背景".tr)
                                .font(.system(size: 15, weight: appearance.systemFontWeight))
                                .foregroundColor(.primary)
                            Spacer()
                            HStack(spacing: 8) {
                                Circle()
                                    .fill(Color(hex: currentHex))
                                    .frame(width: 22, height: 22)
                                    .overlay(Circle().stroke(Color.secondary.opacity(0.25), lineWidth: 1.2))
                                Image(systemName: "chevron.right")
                                    .font(.system(size: 12, weight: .semibold))
                                    .foregroundColor(Color(UIColor.tertiaryLabel))
                            }
                        }
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                }
            }
            
            // MARK: - 设置主页各图标色彩
            Section(
                header: Text("设置主页菜单图标色彩".tr).font(.system(size: 13, weight: appearance.systemFontWeight))
            ) {
                colorRowButton(item: .setLangIcon, hex: appearance.settingsLanguageIconColorHex)
                colorRowButton(item: .setAppIcon, hex: appearance.settingsAppearanceIconColorHex)
                colorRowButton(item: .setWallIcon, hex: appearance.settingsWallpaperIconColorHex)
                colorRowButton(item: .setApiIcon, hex: appearance.settingsApiIconColorHex)
            }
            
            Section(
                header: Text(lang.tr("font_weight_section")).font(.system(size: 13, weight: appearance.systemFontWeight)),
                footer: Text(lang.tr("widget_font_priority_footer")).font(.system(size: 12, weight: appearance.systemFontWeight))
            ) {
                Picker(lang.tr("font_weight_section"), selection: $appearance.systemFontWeightName) {
                    ForEach(fontWeights, id: \.key) { fw in
                        Text(fw.title.tr).tag(fw.key)
                    }
                }
                .pickerStyle(.segmented)
                .padding(.vertical, 4)
                
                Toggle(lang.tr("widget_font_priority"), isOn: $appearance.preferWidgetFontPriority)
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                    .tint(appearance.toggleTintColor)
            }
            
            Section(header: Text(lang.tr("desktop_and_indicators")).font(.system(size: 13, weight: appearance.systemFontWeight))) {
                Toggle(lang.tr("hide_home_indicator"), isOn: $appearance.hideHomeIndicator)
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                    .tint(appearance.toggleTintColor)
                Toggle(lang.tr("hide_status_bar"), isOn: $appearance.hideStatusBar)
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                    .tint(appearance.toggleTintColor)
            }
        }
        .navigationTitle(lang.tr("display_and_brightness"))
        .navigationBarTitleDisplayMode(.inline)
        .tint(appearance.accentTextColor)
        .sheet(item: $activeSheetItem) { item in
            let presets = SystemAppearance.morandiPresets
            switch item {
            case .sliderTrack:
                ProfessionalHSBSheet(title: item.title, storageKey: item.storageKey, hexBinding: $appearance.sliderTrackColorHex, presets: presets)
                    .presentationDetents([.height(400)])
            case .toggleTint:
                ProfessionalHSBSheet(title: item.title, storageKey: item.storageKey, hexBinding: $appearance.toggleTintColorHex, presets: presets)
                    .presentationDetents([.height(400)])
            case .categoryTag:
                ProfessionalHSBSheet(title: item.title, storageKey: item.storageKey, hexBinding: $appearance.categoryTagColorHex, presets: presets)
                    .presentationDetents([.height(400)])
            case .accentText:
                ProfessionalHSBSheet(title: item.title, storageKey: item.storageKey, hexBinding: $appearance.accentTextColorHex, presets: presets)
                    .presentationDetents([.height(400)])
            case .tabBarSelected:
                ProfessionalHSBSheet(title: item.title, storageKey: item.storageKey, hexBinding: $appearance.tabBarSelectedColorHex, presets: presets)
                    .presentationDetents([.height(400)])
            case .setLangIcon:
                ProfessionalHSBSheet(title: item.title, storageKey: item.storageKey, hexBinding: $appearance.settingsLanguageIconColorHex, presets: presets)
                    .presentationDetents([.height(400)])
            case .setAppIcon:
                ProfessionalHSBSheet(title: item.title, storageKey: item.storageKey, hexBinding: $appearance.settingsAppearanceIconColorHex, presets: presets)
                    .presentationDetents([.height(400)])
            case .setWallIcon:
                ProfessionalHSBSheet(title: item.title, storageKey: item.storageKey, hexBinding: $appearance.settingsWallpaperIconColorHex, presets: presets)
                    .presentationDetents([.height(400)])
            case .setApiIcon:
                ProfessionalHSBSheet(title: item.title, storageKey: item.storageKey, hexBinding: $appearance.settingsApiIconColorHex, presets: presets)
                    .presentationDetents([.height(400)])
            case .desktopApp(let appId, _):
                let binding = Binding<String>(
                    get: { iconManager.getColor(for: appId) ?? defaultHexFor(appId) },
                    set: { iconManager.setColor(for: appId, hex: $0) }
                )
                ProfessionalHSBSheet(title: item.title, storageKey: item.storageKey, hexBinding: binding, presets: presets)
                    .presentationDetents([.height(400)])
            }
        }
    }
    
    private func defaultHexFor(_ appId: String) -> String {
        switch appId {
        case "wechat": return "#8FA4B5"
        case "messages": return "#9DB3C4"
        case "phone": return "#9EA3A8"
        case "weather": return "#A3B8C8"
        case "iscreen": return "#A39BAE"
        case "notes": return "#C8A8A8"
        case "qimao": return "#D6BDBD"
        case "anonymous": return "#B5ADC0"
        case "icity": return "#8FA4B5"
        case "music_app": return "#C49A9A"
        case "settings": return "#B4B8BC"
        default: return "#9EA3A8"
        }
    }
    
    private func colorRowButton(item: AppearanceColorItem, hex: String) -> some View {
        Button(action: {
            activeSheetItem = item
        }) {
            HStack {
                Text(item.title)
                    .font(.system(size: 15, weight: appearance.systemFontWeight))
                    .foregroundColor(.primary)
                Spacer()
                HStack(spacing: 8) {
                    Circle()
                        .fill(Color(hex: hex))
                        .frame(width: 22, height: 22)
                        .overlay(Circle().stroke(Color.secondary.opacity(0.25), lineWidth: 1.2))
                    Image(systemName: "chevron.right")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(Color(UIColor.tertiaryLabel))
                }
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

// MARK: - 壁纸设置子页面
struct WallpaperSettingsView: View {
    @ObservedObject var wallpaperManager = WallpaperManager.shared
    @ObservedObject var lang = LanguageManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    
    @State private var lockScreenItem: PhotosPickerItem? = nil
    @State private var homeScreenItem: PhotosPickerItem? = nil
    
    var body: some View {
        ScrollView {
            VStack(spacing: 35) {
                HStack(spacing: 25) {
                    VStack(spacing: 16) {
                        WallpaperPreviewBox(isLockScreen: true, wallpaperData: wallpaperManager.lockScreenData)
                        Text(lang.tr("lock_screen"))
                            .font(.system(size: 15, weight: appearance.systemFontWeight))
                        
                        PhotosPicker(selection: $lockScreenItem, matching: .images, photoLibrary: .shared()) {
                            Text(lang.tr("customize"))
                                .font(.system(size: 14, weight: appearance.systemFontWeight))
                                .foregroundColor(.primary) 
                                .padding(.horizontal, 16)
                                .padding(.vertical, 6)
                                .background(Color.primary.opacity(0.1)) 
                                .clipShape(Capsule())
                        }
                    }
                    
                    VStack(spacing: 16) {
                        WallpaperPreviewBox(isLockScreen: false, wallpaperData: wallpaperManager.homeScreenData)
                        Text(lang.tr("home_screen"))
                            .font(.system(size: 15, weight: appearance.systemFontWeight))
                        
                        PhotosPicker(selection: $homeScreenItem, matching: .images, photoLibrary: .shared()) {
                            Text(lang.tr("customize"))
                                .font(.system(size: 14, weight: appearance.systemFontWeight))
                                .foregroundColor(.primary) 
                                .padding(.horizontal, 16)
                                .padding(.vertical, 6)
                                .background(Color.primary.opacity(0.1)) 
                                .clipShape(Capsule())
                        }
                    }
                }
                .padding(.top, 40)
            }
        }
        .navigationTitle(lang.tr("wallpaper"))
        .navigationBarTitleDisplayMode(.inline)
        .task(id: lockScreenItem) {
            if let data = try? await lockScreenItem?.loadTransferable(type: Data.self) {
                withAnimation(.easeInOut(duration: 0.5)) {
                    wallpaperManager.lockScreenData = data
                }
            }
        }
        .task(id: homeScreenItem) {
            if let data = try? await homeScreenItem?.loadTransferable(type: Data.self) {
                withAnimation(.easeInOut(duration: 0.5)) {
                    wallpaperManager.homeScreenData = data
                }
            }
        }
    }
}

// MARK: - 壁纸预览容器
struct WallpaperPreviewBox: View {
    var isLockScreen: Bool
    var wallpaperData: Data?
    
    var body: some View {
        ZStack(alignment: isLockScreen ? .top : .bottom) {
            NativeImage(data: wallpaperData)
                .frame(width: 140, height: 300)
                .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .stroke(Color.gray.opacity(0.3), lineWidth: 3)
                )
            
            if isLockScreen {
                Text("09:41").font(.system(size: 26, weight: .thin)).padding(.top, 30).foregroundColor(.white)
            } else {
                RoundedRectangle(cornerRadius: 10, style: .continuous)
                    .fill(Color.gray.opacity(0.3))
                    .frame(width: 100, height: 24)
                    .padding(.bottom, 20)
            }
        }
    }
}
