// 📄 文件 1：Widgets/WidgetChatList.swift
import SwiftUI
import PhotosUI

// MARK: - 1. 自动装配插座
final class ChatListWidgetPlugin: BaseWidgetPlugin {
    @MainActor override class func register() {
        WidgetRegistry.shared.registerChatListWidget()
    }
}

// MARK: - 2. 状态管理器 (2×2 规范)
@MainActor
final class ChatListWidgetManager: ObservableObject {
    static let shared = ChatListWidgetManager()
    
    nonisolated var sizeRows: Int { 2 }
    nonisolated var sizeCols: Int { 2 }
    
    // 桌面定位
    @Published var isAddedToDesktop: Bool { didSet { UserDefaults.standard.set(isAddedToDesktop, forKey: "W_CL_Added") } }
    @Published var widgetPage: Int { didSet { UserDefaults.standard.set(widgetPage, forKey: "W_CL_Page") } }
    @Published var widgetRow: Int { didSet { UserDefaults.standard.set(widgetRow, forKey: "W_CL_Row") } }
    @Published var widgetCol: Int { didSet { UserDefaults.standard.set(widgetCol, forKey: "W_CL_Col") } }
    
    // 内容文本
    @Published var contactText: String { didSet { UserDefaults.standard.set(contactText, forKey: "W_CL_Contact") } }
    @Published var batteryText: String { didSet { UserDefaults.standard.set(batteryText, forKey: "W_CL_Battery") } }
    @Published var name1: String { didSet { UserDefaults.standard.set(name1, forKey: "W_CL_Name1") } }
    @Published var message1: String { didSet { UserDefaults.standard.set(message1, forKey: "W_CL_Msg1") } }
    @Published var time1: String { didSet { UserDefaults.standard.set(time1, forKey: "W_CL_Time1") } }
    @Published var status1: String { didSet { UserDefaults.standard.set(status1, forKey: "W_CL_Status1") } }
    @Published var name2: String { didSet { UserDefaults.standard.set(name2, forKey: "W_CL_Name2") } }
    @Published var message2: String { didSet { UserDefaults.standard.set(message2, forKey: "W_CL_Msg2") } }
    @Published var time2: String { didSet { UserDefaults.standard.set(time2, forKey: "W_CL_Time2") } }
    @Published var status2: String { didSet { UserDefaults.standard.set(status2, forKey: "W_CL_Status2") } }
    
    // 外观与开关
    @Published var bgColorMode: String { didSet { UserDefaults.standard.set(bgColorMode, forKey: "W_CL_BgMode") } }
    @Published var autoFollowRealTime: Bool { didSet { UserDefaults.standard.set(autoFollowRealTime, forKey: "W_CL_AutoTime") } }
    
    // 颜色配置
    @Published var mainTextColorHex: String { didSet { UserDefaults.standard.set(mainTextColorHex, forKey: "W_CL_MainColor") } }
    @Published var subTextColorHex: String { didSet { UserDefaults.standard.set(subTextColorHex, forKey: "W_CL_SubColor") } }
    @Published var timeColorHex: String { didSet { UserDefaults.standard.set(timeColorHex, forKey: "W_CL_TimeColor") } }
    
    // 列表圆框描边与圆角
    @Published var hasItemCard: Bool { didSet { UserDefaults.standard.set(hasItemCard, forKey: "W_CL_HasCard") } }
    @Published var itemCardBgHex: String { didSet { UserDefaults.standard.set(itemCardBgHex, forKey: "W_CL_CardBg") } }
    @Published var itemCardBorderHex: String { didSet { UserDefaults.standard.set(itemCardBorderHex, forKey: "W_CL_CardBorder") } }
    @Published var itemCardBorderWidth: Double { didSet { UserDefaults.standard.set(itemCardBorderWidth, forKey: "W_CL_CardBW") } }
    @Published var itemCardCornerRadius: Double { didSet { UserDefaults.standard.set(itemCardCornerRadius, forKey: "W_CL_CardRadius") } }
    
    // 头像圆角自定义 (0.0 为正方形，13.5 为完整正圆形)
    @Published var avatarCornerRadius: Double { didSet { UserDefaults.standard.set(avatarCornerRadius, forKey: "W_CL_AvRadius") } }
    
    // 头像数据
    @Published var avatar1Data: Data? {
        didSet { LocalImageStore.shared.replace(oldId: UserDefaults.standard.string(forKey: "W_CL_Av1"), with: avatar1Data) { UserDefaults.standard.set($0, forKey: "W_CL_Av1") } }
    }
    @Published var avatar2Data: Data? {
        didSet { LocalImageStore.shared.replace(oldId: UserDefaults.standard.string(forKey: "W_CL_Av2"), with: avatar2Data) { UserDefaults.standard.set($0, forKey: "W_CL_Av2") } }
    }
    
    init() {
        let ud = UserDefaults.standard
        self.isAddedToDesktop = ud.bool(forKey: "W_CL_Added")
        self.widgetPage = ud.integer(forKey: "W_CL_Page")
        self.widgetRow = ud.object(forKey: "W_CL_Row") != nil ? ud.integer(forKey: "W_CL_Row") : 2
        self.widgetCol = ud.integer(forKey: "W_CL_Col") > 0 ? 2 : 0
        
        self.contactText = ud.string(forKey: "W_CL_Contact") ?? "contact: // 456076"
        self.batteryText = ud.string(forKey: "W_CL_Battery") ?? "60%"
        self.name1 = ud.string(forKey: "W_CL_Name1") ?? "小雨呆咪"
        self.message1 = ud.string(forKey: "W_CL_Msg1") ?? "对你来说我只是一颗星吗"
        self.time1 = ud.string(forKey: "W_CL_Time1") ?? "09-25"
        self.status1 = ud.string(forKey: "W_CL_Status1") ?? "已读"
        self.name2 = ud.string(forKey: "W_CL_Name2") ?? "流泪猫猫头"
        self.message2 = ud.string(forKey: "W_CL_Msg2") ?? "你是宇宙里唯一的一颗星"
        self.time2 = ud.string(forKey: "W_CL_Time2") ?? "22:31"
        self.status2 = ud.string(forKey: "W_CL_Status2") ?? "未读"
        
        self.bgColorMode = ud.string(forKey: "W_CL_BgMode") ?? "white"
        self.autoFollowRealTime = ud.object(forKey: "W_CL_AutoTime") != nil ? ud.bool(forKey: "W_CL_AutoTime") : true
        
        self.mainTextColorHex = ud.string(forKey: "W_CL_MainColor") ?? ""
        self.subTextColorHex = ud.string(forKey: "W_CL_SubColor") ?? ""
        self.timeColorHex = ud.string(forKey: "W_CL_TimeColor") ?? ""
        
        self.hasItemCard = ud.bool(forKey: "W_CL_HasCard")
        self.itemCardBgHex = ud.string(forKey: "W_CL_CardBg") ?? "#FFFFFF"
        self.itemCardBorderHex = ud.string(forKey: "W_CL_CardBorder") ?? "#E5E5EA"
        self.itemCardBorderWidth = ud.object(forKey: "W_CL_CardBW") != nil ? ud.double(forKey: "W_CL_CardBW") : 0.8
        self.itemCardCornerRadius = ud.object(forKey: "W_CL_CardRadius") != nil ? ud.double(forKey: "W_CL_CardRadius") : 10.0
        
        self.avatarCornerRadius = ud.object(forKey: "W_CL_AvRadius") != nil ? ud.double(forKey: "W_CL_AvRadius") : 13.5
        
        if let id1 = ud.string(forKey: "W_CL_Av1") { self.avatar1Data = LocalImageStore.shared.load(id: id1) }
        if let id2 = ud.string(forKey: "W_CL_Av2") { self.avatar2Data = LocalImageStore.shared.load(id: id2) }
    }
}

extension ChatListWidgetManager: @preconcurrency DesktopWidgetManager {}

// MARK: - 3. 2×2 精密小组件视图
struct ChatListWidget2x2View: View {
    @ObservedObject var manager = ChatListWidgetManager.shared
    var showDashedBorder: Bool = false
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    
    private var isDark: Bool { manager.bgColorMode == "black" }
    private var mainTextC: Color { !manager.mainTextColorHex.isEmpty ? Color(hex: manager.mainTextColorHex) : (isDark ? .white : .black) }
    private var subTextC: Color { !manager.subTextColorHex.isEmpty ? Color(hex: manager.subTextColorHex) : (isDark ? Color.white.opacity(0.85) : Color(hex: "#2C2C2E")) }
    private var timeTextC: Color { !manager.timeColorHex.isEmpty ? Color(hex: manager.timeColorHex) : (isDark ? Color.white.opacity(0.65) : Color(hex: "#8E8E93")) }
    private var barBgC: Color { isDark ? Color(hex: "#2C2C2E") : Color(hex: "#F2F2F7") }
    private var badgeBgC: Color { isDark ? .white : Color(hex: "#F2F2F7") }
    private var badgeTextC: Color { isDark ? .black : Color(hex: "#1C1C1E") }
    
    private var batteryRatio: Double {
        if let val = Double(manager.batteryText.filter { $0.isNumber }) { return min(max(val / 100.0, 0.0), 1.0) }
        return 0.6
    }
    
    var body: some View {
        let s = uiScale
        TimelineView(.periodic(from: .now, by: 10.0)) { context in
            let date = context.date
            ZStack(alignment: .topLeading) {
                // 背景
                Group {
                    if manager.bgColorMode == "transparent" { Color.clear }
                    else if isDark { Color.black }
                    else { Color.white }
                }
                .clipShape(RoundedRectangle(cornerRadius: 22 * s, style: .continuous))
                
                VStack(spacing: 0) {
                    // 状态栏
                    HStack(alignment: .center) {
                        HStack(spacing: 3.5 * s) {
                            Text(weekdayStr(for: date).tr).font(.system(size: 8.5 * s, weight: .semibold))
                            Capsule().fill(mainTextC.opacity(0.35)).frame(width: 1.0 * s, height: 7.2 * s)
                            Text(periodStr(for: date).tr).font(.system(size: 8.5 * s, weight: .semibold))
                        }
                        .foregroundColor(mainTextC)
                        
                        Spacer()
                        
                        HStack(spacing: 3 * s) {
                            Text(manager.batteryText).font(.system(size: 8.6 * s, weight: .medium, design: .rounded)).foregroundColor(mainTextC)
                            ZStack(alignment: .leading) {
                                Capsule().fill(mainTextC.opacity(0.18)).frame(width: 14.5 * s, height: 7.2 * s)
                                Capsule().fill(mainTextC).frame(width: max(2.0 * s, 14.5 * s * CGFloat(batteryRatio)), height: 7.2 * s)
                            }
                        }
                    }
                    .padding(.horizontal, 10 * s).padding(.top, 9.5 * s)
                    
                    // 细横线
                    Rectangle().fill(isDark ? Color.white.opacity(0.16) : Color.black.opacity(0.08)).frame(height: 0.6 * s).padding(.top, 5.5 * s)
                    
                    // 搜索框
                    HStack(spacing: 3 * s) {
                        ZStack {
                            Circle().fill(isDark ? Color.white.opacity(0.12) : Color.black.opacity(0.06)).frame(width: 12.5 * s, height: 12.5 * s)
                            Image(systemName: "lock.fill").font(.system(size: 6.5 * s, weight: .semibold)).foregroundColor(isDark ? .white.opacity(0.7) : .gray)
                        }
                        Spacer(minLength: 1)
                        Text(manager.contactText).font(.system(size: 7.8 * s, weight: .medium)).foregroundColor(isDark ? .white.opacity(0.9) : Color(hex: "#3C3C43")).lineLimit(1).minimumScaleFactor(0.75)
                        Spacer(minLength: 1)
                        Image(systemName: "link").font(.system(size: 7.5 * s, weight: .medium)).foregroundColor(isDark ? .white.opacity(0.7) : .gray)
                    }
                    .padding(.horizontal, 7 * s).frame(height: 19 * s).background(barBgC).clipShape(Capsule())
                    .padding(.horizontal, 8.5 * s).padding(.top, 6.0 * s)
                    
                    // 联系人列表
                    VStack(spacing: manager.hasItemCard ? 6.0 * s : 16.0 * s) {
                        miniChatRow(
                            avatarData: manager.avatar1Data, name: manager.name1, message: manager.message1,
                            time: manager.autoFollowRealTime ? formatDate(date, format: "MM-dd") : manager.time1,
                            statusText: manager.status1, isFirst: true,
                            onToggle: { withAnimation(.spring(response: 0.25, dampingFraction: 0.75)) { manager.status1 = manager.status1 == "已读" ? "未读" : "已读" } }, s: s
                        )
                        miniChatRow(
                            avatarData: manager.avatar2Data, name: manager.name2, message: manager.message2,
                            time: manager.autoFollowRealTime ? formatDate(date, format: "HH:mm") : manager.time2,
                            statusText: manager.status2, isFirst: false,
                            onToggle: { withAnimation(.spring(response: 0.25, dampingFraction: 0.75)) { manager.status2 = manager.status2 == "已读" ? "未读" : "已读" } }, s: s
                        )
                    }
                    .padding(.horizontal, manager.hasItemCard ? 7.0 * s : 8.5 * s)
                    .padding(.top, 12.0 * s)
                    
                    Spacer(minLength: 4 * s)
                }
                
                // 边框
                RoundedRectangle(cornerRadius: 22 * s, style: .continuous)
                    .stroke(manager.bgColorMode == "transparent" ? (showDashedBorder ? Color.secondary.opacity(0.4) : .clear) : Color.primary.opacity(0.06),
                            style: StrokeStyle(lineWidth: 1 * s, dash: (manager.bgColorMode == "transparent" && showDashedBorder) ? [5 * s, 4 * s] : []))
                    .allowsHitTesting(false)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity).clipShape(RoundedRectangle(cornerRadius: 22 * s, style: .continuous))
        }
    }
    
    // 微型联系人行
    private func miniChatRow(avatarData: Data?, name: String, message: String, time: String, statusText: String, isFirst: Bool, onToggle: @escaping () -> Void, s: CGFloat) -> some View {
        let avCornerR = CGFloat(min(manager.avatarCornerRadius, 13.25)) * s
        let avShape = RoundedRectangle(cornerRadius: avCornerR, style: .continuous)
        
        return HStack(spacing: 5.5 * s) {
            // 头像
            Group {
                if let data = avatarData, let uiImg = ImageBitmapCache.shared.image(from: data) {
                    Image(uiImage: uiImg).resizable().scaledToFill()
                } else {
                    ZStack {
                        avShape.fill(isFirst ? Color(hex: "#E5E5EA") : Color(hex: "#D1D1D6"))
                        Image(systemName: "person.fill").font(.system(size: 13.0 * s)).foregroundColor(isFirst ? Color(hex: "#8E8E93") : Color(hex: "#636366")).offset(y: 0.8 * s)
                    }
                }
            }
            .frame(width: 26.5 * s, height: 26.5 * s)
            .clipShape(avShape)
            .overlay(avShape.stroke(Color.primary.opacity(0.08), lineWidth: 0.6 * s))
            
            // 文本信息区
            VStack(alignment: .leading, spacing: 2.2 * s) {
                HStack(alignment: .center) {
                    Text(translator.translate(name)).font(.system(size: 8.2 * s, weight: .bold)).foregroundColor(mainTextC).lineLimit(1)
                    Spacer(minLength: 3 * s)
                    Text(translator.translate(time)).font(.system(size: 6.8 * s, weight: .regular)).foregroundColor(timeTextC).lineLimit(1)
                }
                HStack(alignment: .center, spacing: 3.5 * s) {
                    Text(translator.translate(message))
                        .font(.system(size: 7.5 * s, weight: appearance.systemFontWeight))
                        .foregroundColor(subTextC)
                        .lineLimit(1)
                        .minimumScaleFactor(0.72)
                    
                    Spacer(minLength: 3 * s)
                    
                    Button(action: { UIImpactFeedbackGenerator(style: .light).impactOccurred(); onToggle() }) {
                        Text(translator.translate(statusText)).font(.system(size: 6.0 * s, weight: .semibold)).foregroundColor(badgeTextC)
                            .padding(.horizontal, 3.2 * s).padding(.vertical, 0.8 * s).background(badgeBgC).clipShape(Capsule())
                            .overlay(Capsule().stroke(Color.primary.opacity(0.08), lineWidth: 0.4 * s))
                    }.buttonStyle(.plain)
                }
            }
        }
        .padding(.leading, manager.hasItemCard ? 5.0 * s : 0)
        .padding(.trailing, manager.hasItemCard ? 6.5 * s : 0)
        .padding(.vertical, manager.hasItemCard ? 4.0 * s : 0)
        .background(
            Group {
                if manager.hasItemCard {
                    RoundedRectangle(cornerRadius: CGFloat(manager.itemCardCornerRadius) * s, style: .continuous).fill(Color(hex: manager.itemCardBgHex))
                }
            }
        )
        .overlay(
            Group {
                if manager.hasItemCard {
                    RoundedRectangle(cornerRadius: CGFloat(manager.itemCardCornerRadius) * s, style: .continuous)
                        .stroke(Color(hex: manager.itemCardBorderHex), lineWidth: CGFloat(manager.itemCardBorderWidth) * s)
                }
            }
        )
    }
    
    private func weekdayStr(for date: Date) -> String {
        let w = Calendar.current.component(.weekday, from: date)
        return ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"][max(0, min(w - 1, 6))]
    }
    private func periodStr(for date: Date) -> String {
        let h = Calendar.current.component(.hour, from: date)
        switch h { case 5..<11: return "早上"; case 11..<13: return "中午"; case 13..<18: return "下午"; default: return "晚上" }
    }
    private func formatDate(_ date: Date, format: String) -> String {
        let f = DateFormatter(); f.dateFormat = format; return f.string(from: date)
    }
}

// MARK: - 4. 注册中心连接
extension WidgetRegistry {
    func registerChatListWidget() {
        let mgr = ChatListWidgetManager.shared
        let s = uiScale
        registerWidget(
            id: "chat_list", title: "消息卡片", subtitle: "极简双人对话消息小卡片", badge: "2×2", manager: mgr,
            desktopView: { ChatListWidget2x2View(manager: mgr) },
            previewView: { ChatListWidget2x2View(manager: mgr).frame(width: 160 * s, height: 160 * s) },
            editSheetView: { show in EditChatListWidgetSheet(isPresented: show) }
        )
    }
}
