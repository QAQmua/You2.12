// 📄 完整替换文件：Widgets/WidgetKoreanSheet.swift
import SwiftUI
import PhotosUI

// MARK: - 寄语卡片专属编辑面板（严格对齐 2x2 对话框标准 UI 动画交互版）
@MainActor
struct EditKoreanWidgetSheet: View {
    @Binding var isPresented: Bool
    @ObservedObject var widgetManager = KoreanMessageWidgetManager.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    
    // 是否吸顶常驻置顶预览
    @AppStorage("W_KR_PinPreview") private var isPreviewPinned: Bool = true
    
    // 两大顶级分类：0: 样式 (外观、形态与调色), 1: 内容 (文本与配图)
    @State private var selectedCategoryTab: Int = 0
    @State private var selectedPhotoItem: PhotosPickerItem? = nil
    
    // 🌟 多米诺视口感知联合触发键
    private var triggerKey: String { "\(selectedCategoryTab)" }
    
    // 🌟 严格对齐 2x2 对话框底板模式双向绑定（无损映射 isTransparentBackground）
    private var bgModeBinding: Binding<String> {
        Binding(
            get: { widgetManager.isTransparentBackground ? "transparent" : "color" },
            set: { widgetManager.isTransparentBackground = ($0 == "transparent") }
        )
    }
    
    // HSB 调色面板状态绑定
    @State private var colorPickerTitle: String = ""
    @State private var colorStorageKey: String = ""
    @State private var activeHexBinding: Binding<String>? = nil
    @State private var activePresetColors: [String] = []
    @State private var showHSBSheet: Bool = false
    
    // 预设色盘
    private var morandiPresets: [String] { SystemAppearance.morandiPresets }
    private let widgetBgPresets = ["#EDEDF2", "#FFFFFF", "#1C1C1E", "#FDE2E4", "#E2ECE9", "#FFF1C5", "#D0E1FD", "#E8DFF5"]
    private let borderPresets = ["#E5E5EA", "#000000", "#8E8E93", "#FFFFFF", "#007AFF", "#FF2D55", "#5856D6", "#FF9500"]
    private let textColors = ["#000000", "#FFFFFF", "#3C3C43", "#8E8E93", "#007AFF", "#FF2D55", "#5856D6", "#FF9500"]
    private let boxStyleOptions = [("柔和阴影", "shadow"), ("描边", "border"), ("无", "none")]
    
    private let fontWeights: [(key: String, title: String)] = [
        ("light", "细体"),
        ("regular", "常规"),
        ("medium", "中等"),
        ("semibold", "半粗"),
        ("bold", "粗体")
    ]
    
    var body: some View {
        let s = uiScale
        NavigationStack {
            VStack(spacing: 0) {
                // 1. 【置顶预览区：通体同色系统底板】
                if isPreviewPinned {
                    pinnedHeaderView(s: s)
                        .zIndex(10)
                }
                
                // 2. 【滚动内容区：细颗粒度多米诺逐行级联卡片流】
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        if !isPreviewPinned {
                            pinnedHeaderView(s: s)
                                .padding(.top, 10)
                        }
                        
                        if selectedCategoryTab == 0 {
                            styleCategorySection()
                                .padding(.top, isPreviewPinned ? 14 : 4)
                        } else {
                            contentCategorySection()
                                .padding(.top, isPreviewPinned ? 14 : 4)
                        }
                    }
                    .padding(.bottom, 36)
                }
            }
            .background(Color(UIColor.systemGroupedBackground))
            .navigationTitle("寄语卡片".tr)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                            isPreviewPinned.toggle()
                        }
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: isPreviewPinned ? "pin.fill" : "pin.slash")
                                .font(.system(size: 13, weight: .semibold))
                            Text(isPreviewPinned ? "取消置顶".tr : "置顶预览".tr)
                                .font(.system(size: 13))
                        }
                        .foregroundColor(isPreviewPinned ? appearance.accentTextColor : .secondary)
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成".tr) {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        isPresented = false
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                    .foregroundColor(appearance.accentTextColor)
                }
            }
            // 🌟 统一对话框标准：专业 HSB 调色大弹窗
            .sheet(isPresented: $showHSBSheet) {
                if let hexBinding = activeHexBinding {
                    ProfessionalHSBSheet(
                        title: colorPickerTitle,
                        storageKey: colorStorageKey,
                        hexBinding: hexBinding,
                        presets: activePresetColors
                    )
                    .presentationDetents([.height(400)])
                }
            }
        }
        .presentationDetents([.medium, .large])
        .task(id: selectedPhotoItem) {
            if let data = try? await selectedPhotoItem?.loadTransferable(type: Data.self) {
                withAnimation(.easeInOut(duration: 0.28)) { widgetManager.widgetImageData = data }
                UINotificationFeedbackGenerator().notificationOccurred(.success)
                selectedPhotoItem = nil
            }
        }
    }
    
    // MARK: - 🏆 顶部吸顶区域
    private func pinnedHeaderView(s: CGFloat) -> some View {
        VStack(spacing: 12) {
            KoreanMessageWidget4x2View(manager: widgetManager, showDashedBorder: true)
                .frame(height: 156 * s)
                .shadow(color: Color.black.opacity(0.06), radius: 8, y: 3)
                .padding(.horizontal, 16)
                .contentShape(Rectangle())
            
            Picker("", selection: $selectedCategoryTab.animation(.spring(response: 0.35, dampingFraction: 0.82))) {
                Text("样式".tr).tag(0)
                Text("内容".tr).tag(1)
            }
            .pickerStyle(.segmented)
            .padding(.horizontal, 24)
        }
        .padding(.top, 10)
        .padding(.bottom, 12)
        .frame(maxWidth: .infinity)
        .background(Color(UIColor.systemGroupedBackground))
    }
    
    // MARK: - 📁 分类 1：【样式】
    private func styleCategorySection() -> some View {
        VStack(spacing: 16) {
            // 1. 底板背景卡片（🌟 100% 对齐 2x2 对话框小组件底板交互规范）
            VStack(spacing: 16) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    Picker("", selection: bgModeBinding.animation(.easeInOut(duration: 0.2))) {
                        Text("自选底色".tr).tag("color")
                        Text("完全透明".tr).tag("transparent")
                    }
                    .pickerStyle(.segmented)
                }
                
                if !widgetManager.isTransparentBackground {
                    DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                        sleekColorRow(
                            title: "底板背景颜色".tr,
                            storageKey: "kr_widget_bg",
                            hexBinding: $widgetManager.backgroundColorHex,
                            presets: widgetBgPresets
                        )
                    }
                }
            }
            .modifier(IOSNativeGroupedCard())
            
            // 2. 白框效果卡片（具备 16pt 嵌套子容器）
            VStack(spacing: 16) {
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("白框效果".tr)
                            .font(.system(size: 15, weight: appearance.systemFontWeight))
                        
                        Picker("", selection: $widgetManager.boxStyle.animation(.easeInOut(duration: 0.2))) {
                            ForEach(boxStyleOptions, id: \.1) { item in
                                Text(item.0.tr).tag(item.1)
                            }
                        }
                        .pickerStyle(.segmented)
                    }
                }
                
                // 白框描边从属子容器（16pt 黄金同心圆角子容器）
                if widgetManager.boxStyle == "border" {
                    VStack(spacing: 14) {
                        DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("白框描边粗细".tr)
                                        .font(.system(size: 14, weight: appearance.systemFontWeight))
                                        .foregroundColor(.secondary)
                                    Spacer()
                                    Text(String(format: "%.1f pt", widgetManager.boxBorderWidth))
                                        .font(.system(size: 12, weight: .medium, design: .monospaced))
                                        .foregroundColor(.secondary)
                                }
                                Slider(value: $widgetManager.boxBorderWidth, in: 0.1...5.0, step: 0.1)
                                    .tint(appearance.sliderTrackColor)
                            }
                        }
                        
                        DominoScrollRevealWrapper(step: 3, triggerKey: triggerKey) {
                            sleekColorRow(
                                title: "白框描边颜色".tr,
                                storageKey: "kr_box_border",
                                hexBinding: $widgetManager.boxBorderColorHex,
                                presets: borderPresets
                            )
                        }
                    }
                    .modifier(IOSNativeSubBox())
                }
            }
            .modifier(IOSNativeGroupedCard())
            
            // 3. 头像与印章形态卡片
            VStack(spacing: 18) {
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("头像大小".tr)
                                .font(.system(size: 15, weight: appearance.systemFontWeight))
                                .foregroundColor(.primary)
                            Spacer()
                            Text("\(Int(widgetManager.avatarSize)) pt")
                                .font(.system(size: 13, weight: .medium, design: .monospaced))
                                .foregroundColor(.secondary)
                        }
                        Slider(value: $widgetManager.avatarSize, in: 28...50, step: 1)
                            .tint(appearance.sliderTrackColor)
                    }
                }
                
                DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("印章图标大小".tr)
                                .font(.system(size: 15, weight: appearance.systemFontWeight))
                                .foregroundColor(.primary)
                            Spacer()
                            Text("\(Int(widgetManager.sealSize)) pt")
                                .font(.system(size: 13, weight: .medium, design: .monospaced))
                                .foregroundColor(.secondary)
                        }
                        Slider(value: $widgetManager.sealSize, in: 14...30, step: 1)
                            .tint(appearance.sliderTrackColor)
                    }
                }
                
                DominoScrollRevealWrapper(step: 3, triggerKey: triggerKey) {
                    sleekColorRow(
                        title: "印章图标颜色".tr,
                        storageKey: "kr_seal_color",
                        hexBinding: $widgetManager.sealColorHex,
                        presets: textColors
                    )
                }
            }
            .modifier(IOSNativeGroupedCard())
            
            // 4. 字体排版卡片组（各部分精细排版）
            unifiedTypographyCard(
                title: "顶部标题排版".tr,
                stepBase: 1,
                storagePrefix: "kr_header",
                sizeBinding: $widgetManager.headerSize,
                minSize: 7, maxSize: 18,
                weightNameBinding: $widgetManager.headerWeightName,
                colorHexBinding: $widgetManager.headerColorHex
            )
            
            unifiedTypographyCard(
                title: "个人昵称排版".tr,
                stepBase: 2,
                storagePrefix: "kr_name",
                sizeBinding: $widgetManager.nameSize,
                minSize: 9, maxSize: 20,
                weightNameBinding: $widgetManager.nameWeightName,
                colorHexBinding: $widgetManager.nameColorHex
            )
            
            unifiedTypographyCard(
                title: "第一排左侧排版".tr,
                stepBase: 3,
                storagePrefix: "kr_left",
                sizeBinding: $widgetManager.leftSize,
                minSize: 9, maxSize: 18,
                weightNameBinding: $widgetManager.leftWeightName,
                colorHexBinding: $widgetManager.leftColorHex
            )
            
            unifiedTypographyCard(
                title: "第一排右侧排版".tr,
                stepBase: 4,
                storagePrefix: "kr_right",
                sizeBinding: $widgetManager.rightSize,
                minSize: 8, maxSize: 16,
                weightNameBinding: $widgetManager.rightWeightName,
                colorHexBinding: $widgetManager.rightColorHex
            )
            
            unifiedTypographyCard(
                title: "第二排签名排版".tr,
                stepBase: 5,
                storagePrefix: "kr_second",
                sizeBinding: $widgetManager.secondSize,
                minSize: 9, maxSize: 18,
                weightNameBinding: $widgetManager.secondWeightName,
                colorHexBinding: $widgetManager.secondColorHex
            )
        }
    }
    
    // MARK: - 📝 分类 2：【内容】
    private func contentCategorySection() -> some View {
        VStack(spacing: 16) {
            // 头像照片选取卡片
            DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                HStack(spacing: 14) {
                    ZStack {
                        if let data = widgetManager.widgetImageData, let uiImg = UIImage(data: data) {
                            Image(uiImage: uiImg)
                                .resizable()
                                .scaledToFill()
                                .transition(.blurFade)
                        } else {
                            Color(UIColor.tertiarySystemFill)
                            Image(systemName: "person.fill")
                                .font(.system(size: 20))
                                .foregroundColor(.secondary)
                                .transition(.opacity)
                        }
                    }
                    .frame(width: 52, height: 52)
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    
                    PhotosPicker(selection: $selectedPhotoItem, matching: .images, photoLibrary: .shared()) {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(widgetManager.widgetImageData == nil ? "选取卡片头像".tr : "更换卡片头像".tr)
                                .font(.system(size: 15, weight: .medium))
                                .foregroundColor(.primary)
                            Text(widgetManager.widgetImageData == nil ? "点击从相册选取头像".tr : "点击重新选择替换头像".tr)
                                .font(.system(size: 12))
                                .foregroundColor(.secondary)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    
                    ZStack {
                        if widgetManager.widgetImageData != nil {
                            Button(action: {
                                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                withAnimation(.easeInOut(duration: 0.28)) { widgetManager.widgetImageData = nil }
                            }) {
                                Image(systemName: "xmark.circle.fill")
                                    .font(.system(size: 20))
                                    .foregroundColor(Color(UIColor.tertiaryLabel))
                                    .frame(width: 32, height: 32)
                                    .contentShape(Circle())
                            }
                            .buttonStyle(.plain)
                        } else {
                            Image(systemName: "chevron.right")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(Color(UIColor.tertiaryLabel))
                        }
                    }
                }
                .modifier(IOSNativeGroupedCard())
            }
            
            // 卡片文案编辑输入卡片流
            VStack(spacing: 14) {
                singleContentInputField(
                    title: "顶部标题".tr,
                    placeholder: "如：보내기 ♡",
                    textBinding: $widgetManager.headerTitle,
                    step: 1
                )
                
                singleContentInputField(
                    title: "个人昵称".tr,
                    placeholder: "如：디저트",
                    textBinding: $widgetManager.profileName,
                    step: 2
                )
                
                singleContentInputField(
                    title: "第一排左侧文案".tr,
                    placeholder: "如：고생 끝에 낙이 온다",
                    textBinding: $widgetManager.firstBarLeftText,
                    step: 3
                )
                
                singleContentInputField(
                    title: "第一排右侧文案".tr,
                    placeholder: "如：슬프다",
                    textBinding: $widgetManager.firstBarRightText,
                    step: 4
                )
                
                singleContentInputField(
                    title: "第二排签名/账号".tr,
                    placeholder: "如：kunoouc",
                    textBinding: $widgetManager.secondBarText,
                    step: 5
                )
            }
            .modifier(IOSNativeGroupedCard())
        }
    }
    
    // MARK: - 辅助子视图构建器
    
    // 单项输入框
    private func singleContentInputField(
        title: String,
        placeholder: String,
        textBinding: Binding<String>,
        step: Int
    ) -> some View {
        DominoScrollRevealWrapper(step: step, triggerKey: triggerKey) {
            VStack(alignment: .leading, spacing: 6) {
                Text(title)
                    .font(.system(size: 13, weight: appearance.systemFontWeight))
                    .foregroundColor(.secondary)
                
                HStack {
                    TextField(placeholder, text: textBinding)
                        .font(.system(size: 15))
                        .onChange(of: textBinding.wrappedValue) { _, newText in
                            translator.prewarm(text: newText)
                        }
                    
                    if !textBinding.wrappedValue.isEmpty {
                        Button(action: {
                            UIImpactFeedbackGenerator(style: .light).impactOccurred()
                            textBinding.wrappedValue = ""
                        }) {
                            Image(systemName: "xmark.circle.fill")
                                .font(.system(size: 16))
                                .foregroundColor(Color(UIColor.tertiaryLabel))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 12)
                .background(Color(UIColor.tertiarySystemFill))
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
        }
    }
    
    // 对齐对话框标准的统一排版卡片
    private func unifiedTypographyCard(
        title: String,
        stepBase: Int,
        storagePrefix: String,
        sizeBinding: Binding<Double>,
        minSize: Double,
        maxSize: Double,
        weightNameBinding: Binding<String>,
        colorHexBinding: Binding<String>
    ) -> some View {
        VStack(spacing: 16) {
            DominoScrollRevealWrapper(step: stepBase, triggerKey: triggerKey) {
                HStack {
                    Text(title)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.primary)
                    Spacer()
                }
            }
            
            DominoScrollRevealWrapper(step: stepBase + 1, triggerKey: triggerKey) {
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text("字号大小".tr)
                            .font(.system(size: 15, weight: appearance.systemFontWeight))
                        Spacer()
                        Text(String(format: "%.1f pt", sizeBinding.wrappedValue))
                            .font(.system(size: 13, weight: .medium, design: .monospaced))
                            .foregroundColor(.secondary)
                    }
                    Slider(value: sizeBinding, in: minSize...maxSize, step: 0.5)
                        .tint(appearance.sliderTrackColor)
                }
            }
            
            DominoScrollRevealWrapper(step: stepBase + 2, triggerKey: triggerKey) {
                HStack {
                    Text("字体粗细".tr)
                        .font(.system(size: 15, weight: appearance.systemFontWeight))
                        .foregroundColor(.primary)
                    Spacer()
                    
                    Menu {
                        ForEach(fontWeights, id: \.key) { fw in
                            Button {
                                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                weightNameBinding.wrappedValue = fw.key
                            } label: {
                                HStack {
                                    Text(fw.title.tr)
                                    if weightNameBinding.wrappedValue == fw.key {
                                        Image(systemName: "checkmark")
                                    }
                                }
                            }
                        }
                    } label: {
                        HStack(spacing: 4) {
                            Text(fontWeights.first(where: { $0.key == weightNameBinding.wrappedValue })?.title.tr ?? "常规".tr)
                                .font(.system(size: 15))
                                .foregroundColor(.secondary)
                            Image(systemName: "chevron.up.chevron.down")
                                .font(.system(size: 12))
                                .foregroundColor(.secondary.opacity(0.6))
                        }
                    }
                }
            }
            
            DominoScrollRevealWrapper(step: stepBase + 3, triggerKey: triggerKey) {
                sleekColorRow(
                    title: "字体颜色".tr,
                    storageKey: "\(storagePrefix)_color",
                    hexBinding: colorHexBinding,
                    presets: textColors
                )
            }
        }
        .modifier(IOSNativeGroupedCard())
    }
    
    // 调色整行入口
    private func sleekColorRow(title: String, storageKey: String, hexBinding: Binding<String>, presets: [String]) -> some View {
        Button(action: {
            colorPickerTitle = title
            colorStorageKey = storageKey
            activeHexBinding = hexBinding
            activePresetColors = presets
            showHSBSheet = true
        }) {
            HStack {
                Text(title)
                    .font(.system(size: 15, weight: appearance.systemFontWeight))
                    .foregroundColor(.primary)
                Spacer()
                
                HStack(spacing: 8) {
                    Circle()
                        .fill(hexBinding.wrappedValue.isEmpty ? Color.clear : Color(hex: hexBinding.wrappedValue))
                        .frame(width: 25, height: 25)
                        .overlay(Circle().stroke(Color.primary.opacity(0.12), lineWidth: 1.0))
                    
                    Image(systemName: "chevron.right")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(Color(UIColor.tertiaryLabel))
                }
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

// MARK: - 🌟 26pt 饱满同心超椭圆大圆角主卡片（对话框标准原生 glassEffect 适配）
private struct IOSNativeGroupedCard: ViewModifier {
    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: 26, style: .continuous)
        content
            .padding(16)
            .background {
                if #available(iOS 26.0, *) {
                    Color.clear
                        .background(Color(UIColor.secondarySystemGroupedBackground))
                        .glassEffect(.regular.interactive(), in: shape)
                } else {
                    Color(UIColor.secondarySystemGroupedBackground)
                }
            }
            .clipShape(shape)
            .padding(.horizontal, 16)
    }
}

// MARK: - 🌟 16pt 黄金同心圆角子容器（灰色从属盒子）
private struct IOSNativeSubBox: ViewModifier {
    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: 16, style: .continuous)
        content
            .padding(14)
            .background {
                if #available(iOS 26.0, *) {
                    Color(UIColor.tertiarySystemFill).opacity(0.55)
                        .glassEffect(.clear, in: shape)
                } else {
                    Color(UIColor.tertiarySystemFill).opacity(0.45)
                }
            }
            .clipShape(shape)
    }
}
