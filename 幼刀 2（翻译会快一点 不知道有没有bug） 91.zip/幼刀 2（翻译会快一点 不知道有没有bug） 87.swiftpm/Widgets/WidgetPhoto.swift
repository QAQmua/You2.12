// 📄 完整替换文件：Widgets/WidgetPhoto.swift
import SwiftUI
import PhotosUI

final class PhotoWidgetPlugin: BaseWidgetPlugin {
    @MainActor override class func register() {
        WidgetRegistry.shared.registerPhotoWidget()
    }
}

class PhotoWidgetManager: ObservableObject {
    static let shared = PhotoWidgetManager()
    
    private let photoIdKey = "App_Widget_4x2_ImageID"
    private let addedKey = "App_Widget_4x2_IsAdded"
    private let pageKey = "App_Widget_4x2_PagePosition"
    private let rowKey = "App_Widget_4x2_RowPosition"
    
    @Published var widgetImageData: Data? {
        didSet {
            let oldId = UserDefaults.standard.string(forKey: photoIdKey)
            LocalImageStore.shared.replace(oldId: oldId, with: widgetImageData) { newId in
                UserDefaults.standard.set(newId, forKey: self.photoIdKey)
            }
        }
    }
    @Published var isAddedToDesktop: Bool { didSet { UserDefaults.standard.set(isAddedToDesktop, forKey: addedKey) } }
    @Published var widgetPage: Int { didSet { UserDefaults.standard.set(widgetPage, forKey: pageKey) } }
    @Published var widgetRow: Int { didSet { UserDefaults.standard.set(widgetRow, forKey: rowKey) } }
    
    init() {
        if let savedId = UserDefaults.standard.string(forKey: photoIdKey) {
            self.widgetImageData = LocalImageStore.shared.load(id: savedId)
        }
        self.isAddedToDesktop = UserDefaults.standard.bool(forKey: addedKey)
        self.widgetPage = UserDefaults.standard.integer(forKey: pageKey)
        let rawRow = UserDefaults.standard.integer(forKey: rowKey)
        self.widgetRow = min(max(0, rawRow), 4)
    }
}

struct PhotoWidget4x2View: View {
    @ObservedObject var manager = PhotoWidgetManager.shared
    @State private var selectedPhotoItem: PhotosPickerItem? = nil
    
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    
    var body: some View {
        let s = uiScale
        
        GeometryReader { geo in
            ZStack(alignment: .topLeading) {
                Group {
                    if let data = manager.widgetImageData, let uiImage = ImageBitmapCache.shared.image(from: data) {
                        Image(uiImage: uiImage)
                            .resizable()
                            .scaledToFill()
                            .frame(width: geo.size.width, height: geo.size.height)
                            .clipped()
                    } else {
                        ZStack {
                            LinearGradient(
                                colors: [Color.purple.opacity(0.35), Color.blue.opacity(0.25)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                            VStack(spacing: 8 * s) {
                                Image(systemName: "photo.on.rectangle.angled")
                                    .font(.system(size: 32 * s))
                                    .foregroundColor(.white.opacity(0.9))
                                Text(translator.translate("卡片"))
                                    .font(.system(size: 15 * s))
                                    .fontWeight(appearance.systemFontWeight)
                                    .foregroundColor(.white)
                                Text(translator.translate("点击选取相册照片"))
                                    .font(.system(size: 11 * s))
                                    .fontWeight(appearance.systemFontWeight)
                                    .foregroundColor(.white.opacity(0.8))
                            }
                        }
                        .frame(width: geo.size.width, height: geo.size.height)
                    }
                }
                .clipShape(RoundedRectangle(cornerRadius: 22 * s, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 22 * s, style: .continuous)
                        .stroke(Color.white.opacity(0.18), lineWidth: 1 * s)
                )
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .clipShape(RoundedRectangle(cornerRadius: 22 * s, style: .continuous))
        }
        .clipShape(RoundedRectangle(cornerRadius: 22 * s, style: .continuous))
        .contentShape(RoundedRectangle(cornerRadius: 22 * s, style: .continuous))
    }
}

// MARK: - 卡片小组件专属定制弹窗（同步 2x2 相册插画顶级版）
struct EditPhotoWidgetSheet: View {
    @Binding var isPresented: Bool
    @ObservedObject var manager = PhotoWidgetManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    
    @AppStorage("W_PH_PinPreview") private var isPreviewPinned: Bool = true
    @State private var selectedPhotoItem: PhotosPickerItem? = nil
    
    var body: some View {
        let s = uiScale
        NavigationStack {
            VStack(spacing: 0) {
                if isPreviewPinned {
                    pinnedHeaderView(s: s)
                        .overlay(alignment: .bottom) {
                            ZStack {
                                Rectangle().fill(.ultraThinMaterial)
                                LinearGradient(
                                    colors: [Color(UIColor.systemGroupedBackground), Color(UIColor.systemGroupedBackground).opacity(0)],
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            }
                            .frame(height: 18)
                            .offset(y: 18)
                            .mask(
                                LinearGradient(
                                    stops: [.init(color: .black, location: 0.0), .init(color: .black.opacity(0.6), location: 0.4), .init(color: .clear, location: 1.0)],
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            )
                            .allowsHitTesting(false)
                        }
                        .zIndex(10)
                }
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        if !isPreviewPinned {
                            pinnedHeaderView(s: s)
                                .padding(.top, 10)
                        }
                        
                        VStack(alignment: .leading, spacing: 14) {
                            DominoScrollRevealWrapper(step: 0, triggerKey: "photo_tab") {
                                Text("卡片照片设置".tr)
                                    .font(.system(size: 13, weight: appearance.systemFontWeight))
                                    .foregroundColor(.secondary)
                            }
                            
                            Divider()
                            
                            DominoScrollRevealWrapper(step: 1, triggerKey: "photo_tab") {
                                HStack(spacing: 12) {
                                    ZStack {
                                        if let data = manager.widgetImageData, let uiImg = UIImage(data: data) {
                                            Image(uiImage: uiImg).resizable().scaledToFill()
                                        } else {
                                            Color(UIColor.tertiarySystemFill)
                                            Image(systemName: "photo").font(.system(size: 18)).foregroundColor(.secondary)
                                        }
                                    }
                                    .frame(width: 52, height: 52)
                                    .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
                                    
                                    PhotosPicker(selection: $selectedPhotoItem, matching: .images, photoLibrary: .shared()) {
                                        VStack(alignment: .leading, spacing: 3) {
                                            Text(manager.widgetImageData == nil ? "选取卡片照片".tr : "更换卡片照片".tr)
                                                .font(.system(size: 15, weight: .medium)).foregroundColor(.primary)
                                            Text("点击从相册挑选展示照片".tr).font(.system(size: 12)).foregroundColor(.secondary)
                                        }
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        .contentShape(Rectangle())
                                    }
                                    .buttonStyle(.plain)
                                    
                                    if manager.widgetImageData != nil {
                                        Button(action: {
                                            UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                            withAnimation(.easeInOut(duration: 0.28)) { manager.widgetImageData = nil }
                                        }) {
                                            Image(systemName: "xmark.circle.fill").font(.system(size: 20)).foregroundColor(Color(UIColor.tertiaryLabel))
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                                .padding(.horizontal, 12).padding(.vertical, 10)
                                .background(Color(UIColor.tertiarySystemFill).opacity(0.55)).cornerRadius(14)
                            }
                        }
                        .padding(16)
                        .background(Color(UIColor.secondarySystemGroupedBackground))
                        .cornerRadius(18)
                        .padding(.horizontal, 16)
                        .padding(.top, isPreviewPinned ? 14 : 0)
                    }
                    .padding(.bottom, 36)
                }
            }
            .background(Color(UIColor.systemGroupedBackground))
            .navigationTitle("卡片照片 (4×2)".tr)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                            isPreviewPinned.toggle()
                        }
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: isPreviewPinned ? "pin.fill" : "pin.slash")
                                .font(.system(size: 13, weight: .semibold))
                            Text(isPreviewPinned ? "取消置顶".tr : "置顶预览".tr)
                                .font(.system(size: 13))
                        }
                        .foregroundColor(isPreviewPinned ? appearance.accentTextColor : .secondary)
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成".tr) {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        isPresented = false
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                    .foregroundColor(appearance.accentTextColor)
                }
            }
            .task(id: selectedPhotoItem) {
                if let data = try? await selectedPhotoItem?.loadTransferable(type: Data.self) {
                    withAnimation(.easeInOut(duration: 0.25)) { manager.widgetImageData = data }
                    UINotificationFeedbackGenerator().notificationOccurred(.success)
                    selectedPhotoItem = nil
                }
            }
        }
        .presentationDetents([.medium])
    }
    
    private func pinnedHeaderView(s: CGFloat) -> some View {
        VStack(spacing: 12) {
            PhotoWidget4x2View()
                .frame(height: 156 * s)
                .shadow(color: Color.black.opacity(0.06), radius: 8, y: 3)
                .padding(.horizontal, 16)
        }
        .padding(.top, 10)
        .padding(.bottom, 12)
        .frame(maxWidth: .infinity)
        .background(Color(UIColor.systemGroupedBackground))
    }
}

extension WidgetRegistry {
    func registerPhotoWidget() {
        let s = uiScale
        registerWidget(
            id: "photo",
            title: "widget_photo_title",
            subtitle: "sub_photo",
            badge: "4×2",
            manager: PhotoWidgetManager.shared,
            desktopView: {
                PhotoWidget4x2View()
            },
            previewView: {
                PhotoWidget4x2View()
                    .frame(height: 160 * s)
                    .padding(.horizontal, 16 * s)
            },
            editSheetView: { show in
                EditPhotoWidgetSheet(isPresented: show)
            }
        )
    }
}
