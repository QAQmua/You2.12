// 📄 文件路径：信息/ChatNotificationManager.swift
import Foundation
import UserNotifications

@MainActor
class ChatNotificationManager: NSObject, UNUserNotificationCenterDelegate {
    static let shared = ChatNotificationManager()
    
    private override init() {
        super.init()
        UNUserNotificationCenter.current().delegate = self
    }
    
    /// 1. 请求系统锁屏与横幅通知权限
    func requestAuthorization() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if granted {
                print("✅ 锁屏通知权限已获取")
            } else if let error = error {
                print("❌ 授权失败: \(error.localizedDescription)")
            }
        }
    }
    
    /// 2. 触发一条真实的系统锁屏弹窗通知
    /// - Parameters:
    ///   - senderName: 对方昵称（例如：爸爸）
    ///   - messageText: 消息内容（例如：今晚回家吃饭吗？）
    ///   - conversationID: 用于锁屏相同联系人通知“折叠收纳”（与原生 iMessage 一致）
    ///   - delay: 延迟几秒触发（锁屏测试建议留 2~3 秒让你按电源键息屏）
    func scheduleMessageNotification(
        senderName: String,
        messageText: String,
        conversationID: String,
        delay: TimeInterval = 1.0
    ) {
        let content = UNMutableNotificationContent()
        content.title = senderName
        content.body = messageText
        content.sound = .default // 锁屏提示音
        
        // 🌟 锁屏同人消息自动折叠收拢
        content.threadIdentifier = conversationID
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: max(delay, 1.0), repeats: false)
        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: trigger
        )
        
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("❌ 发送锁屏通知失败: \(error.localizedDescription)")
            }
        }
    }
    
    /// 3. 前台活跃时依然允许横幅弹窗与声音
    nonisolated func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void
    ) {
        completionHandler([.banner, .sound, .list])
    }
}
